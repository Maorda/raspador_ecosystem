import re
import unicodedata
from typing import Any, Dict, List, Tuple
from playwright.async_api import Page, TimeoutError as PlaywrightTimeoutError
from infra.logger import get_logger
from infra.pure_utils import sanitizar_texto, normalizar_comparacion, validar_partida_registral
from plugins.remaju.pre_extract import (
    SELECTOR_TABS,
    SELECTOR_PANEL_REMATE,
    SELECTOR_PANEL_INMUEBLES,
    SELECTOR_TABLA_INMUEBLES,
    SELECTOR_RESUMEN_UBICACION,
    SELECTOR_PANEL_CRONOGRAMA,
    SELECTOR_TABLA_CRONOGRAMA,
    PreExtractValidator
)

logger = get_logger("remaju_plugin")


class RemajuExtractor:
    """
    Módulo agnóstico encargado del Momento 2: Extracción pura de datos,
    parseo de tablas, validación de partidas y estructuración de DTOs.
    """

    def __init__(self, page: Page | None, app_config: Dict[str, Any], pre_validator: PreExtractValidator) -> None:
        self.page = page
        self.app_config = app_config
        self.pre_validator = pre_validator

    def _require_page(self) -> Page:
        if self.page is None or self.page.is_closed():
            raise RuntimeError("La página de Playwright não está disponible o se encuentra cerrada.")
        return self.page

    async def _extraer_campos_etiquetados(self, panel_selector: str, mapeo: Dict[str, str]) -> Dict[str, str]:
        """Extrae de forma genérica pares clave-valor basados en etiquetas estelares (PrimeFaces PanelGrid)."""
        page = self._require_page()
        panel = page.locator(panel_selector)
        await panel.wait_for(state="visible", timeout=10000)
        
        etiquetas_deseadas = {clave: normalizar_comparacion(etiqueta) for clave, etiqueta in mapeo.items()}
        resultado = {clave: "" for clave in mapeo}
        etiquetas = panel.locator(".ui-panelgrid-cell.text-bold")
        
        for indice in range(await etiquetas.count()):
            etiqueta = etiquetas.nth(indice)
            texto_etiqueta = normalizar_comparacion(await etiqueta.inner_text())
            claves = [clave for clave, texto_configurado in etiquetas_deseadas.items() if texto_configurado == texto_etiqueta]
            if not claves:
                continue
            
            valor_locator = etiqueta.locator("xpath=following-sibling::div[contains(concat(' ', normalize-space(@class), ' '), ' ui-panelgrid-cell ')][1]")
            if await valor_locator.count() == 0:
                continue
            
            valor = sanitizar_texto(await valor_locator.first.inner_text())
            for clave in claves:
                resultado[clave] = valor
        return resultado

    async def _extraer_datos_remate(self) -> Dict[str, Any]:
        """Extrae los campos de la pestaña principal de Remate."""
        page = self._require_page()
        panel = page.locator(SELECTOR_PANEL_REMATE)
        await panel.wait_for(state="visible", timeout=15000)
        
        datos = await self._extraer_campos_etiquetados(SELECTOR_PANEL_REMATE, self.app_config.get("mapeo_remate", {}))
        
        descripcion = panel.locator(".texto-info-scroll").first
        datos["descripcion"] = sanitizar_texto(await descripcion.inner_text()) if await descripcion.count() else ""
        
        enlace_pdf = panel.locator('a.ui-commandlink[title="Descargar"]').filter(has_text=re.compile(r"resolucion\.pdf", re.IGNORECASE))
        datos["archivoUrl"] = sanitizar_texto(await enlace_pdf.first.inner_text()) if await enlace_pdf.count() else ""
        
        if not datos.get("tipoCambio"):
            tipo_cambio = panel.locator("span.label-danger.text-bold")
            if await tipo_cambio.count():
                datos["tipoCambio"] = sanitizar_texto(await tipo_cambio.first.inner_text())
        return datos

    async def _extraer_datos_inmuebles(self) -> Tuple[Dict[str, str], List[Dict[str, str]], List[Dict[str, Any]]]:
        """Extrae los datos de ubicación y la tabla de inmuebles, separando partidas válidas de las que requieren revisión."""
        page = self._require_page()
        mapeo = self.app_config.get("mapeo_inmuebles", {})
        mapeo_ubicacion = {clave: mapeo[clave] for clave in ("departamento", "provincia", "distrito") if clave in mapeo}
        
        ubicacion: Dict[str, str] = {}
        if mapeo_ubicacion:
            contenedor = page.locator(SELECTOR_RESUMEN_UBICACION)
            if await contenedor.count():
                await contenedor.first.wait_for(state="visible", timeout=10000)
                ubicacion = await self._extraer_campos_etiquetados(SELECTOR_RESUMEN_UBICACION, mapeo_ubicacion)

        tbody = page.locator(SELECTOR_TABLA_INMUEBLES)
        await tbody.wait_for(state="visible", timeout=15000)
        filas = tbody.locator("tr[data-ri]")

        inmuebles: List[Dict[str, str]] = []
        partidas_invalidas: List[Dict[str, Any]] = []
        claves_por_columna = ["partidaRegistral", "tipoInmueble", "direccion", "cargaYGravamen", "porcentajeRematar", "imagenes"]

        for indice in range(await filas.count()):
            fila = filas.nth(indice)
            celdas = fila.locator(":scope > td")
            if await celdas.count() < 5:
                continue

            valores = []
            for icelda in range(await celdas.count()):
                celda = celdas.nth(icelda)
                texto = await celda.evaluate("""(el) => {
                    const clon = el.cloneNode(true);
                    clon.querySelectorAll('.ui-column-title').forEach(n => n.remove());
                    return clon.innerText || clon.textContent || '';
                }""")
                valores.append(sanitizar_texto(texto))

            inmueble = {}
            for col_idx, clave in enumerate(claves_por_columna):
                if col_idx < len(valores) and (clave in mapeo or clave == "imagenes"):
                    inmueble[clave] = valores[col_idx]

            partida_original = inmueble.get("partidaRegistral", "")
            partida_limpia = partida_original.strip()

            if not validar_partida_registral(partida_limpia):
                partidas_invalidas.append({
                    "fila_remaju": indice,
                    "partida_original": partida_original,
                    "motivo": "partida_vacia" if not partida_limpia else "formato_partida_registral_invalido",
                    "inmueble": inmueble,
                })
                logger.warning("[REVISION-MANUAL] Fila de inmueble %s excluida. Partida: %r", indice, partida_original)
                continue

            inmueble["partidaRegistral"] = partida_limpia
            inmuebles.append(inmueble)

        return ubicacion, inmuebles, partidas_invalidas

    async def _extraer_datos_cronograma(self) -> Dict[str, str]:
        """Extrae y mapea las fechas e hitos del cronograma de fases del remate."""
        page = self._require_page()
        tbody = page.locator(SELECTOR_TABLA_CRONOGRAMA)
        await tbody.wait_for(state="visible", timeout=15000)
        filas = tbody.locator("tr[data-ri]")
        fases: Dict[str, Dict[str, str]] = {}
        
        for indice in range(await filas.count()):
            celdas = filas.nth(indice).locator(":scope > td")
            if await celdas.count() < 4:
                continue
            fase = sanitizar_texto(await celdas.nth(1).inner_text())
            f_inicio = sanitizar_texto(await celdas.nth(2).inner_text())
            f_fin = sanitizar_texto(await celdas.nth(3).inner_text())
            clave_fase = normalizar_comparacion(fase)
            if clave_fase:
                fases[clave_fase] = {"inicio": f_inicio, "fin": f_fin}

        resultado: Dict[str, str] = {}
        mapeo = self.app_config.get("mapeo_cronograma", {})
        for clave_dto, nombre_fase in mapeo.items():
            fase = fases.get(normalizar_comparacion(nombre_fase), {})
            if "inicio" in clave_dto.casefold():
                resultado[clave_dto] = fase.get("inicio", "")
            elif "fin" in clave_dto.casefold():
                resultado[clave_dto] = fase.get("fin", "")
            else:
                resultado[clave_dto] = ""
        return resultado

    async def extract_tab_remate_completo(self, motor_sincronizar_fn = None) -> Dict[str, Any]:
        """Orquestador principal que combina el Momento 1 (Validación y Motor) y el Momento 2 (Extracción pura)."""
        page = self._require_page()
        
        # MOMENTO 1: Validar el contenedor global de pestañas y sincronizar estrictamente el spinner del motor
        await page.locator(SELECTOR_TABS).wait_for(state="visible", timeout=15000)
        if motor_sincronizar_fn:
            await motor_sincronizar_fn(page)

        # Ejecutar la validación completa del detalle cargado asegurando el paso de `page` al motor
        await self.pre_validator.esperar_detalle_cargado(motor_sincronizar_fn=motor_sincronizar_fn)

        datos: Dict[str, Any] = {"remate": {}, "inmuebles": [], "cronograma": {}}

        # 1. Extracción de Remate (Pestaña por defecto)
        datos["remate"] = await self._extraer_datos_remate()

        # 2. Activación y Extracción de Inmuebles
        await self.pre_validator.activar_pestana(
            indice=1,
            selector_panel=SELECTOR_PANEL_INMUEBLES,
            selector_contenido=SELECTOR_TABLA_INMUEBLES,
            motor_sincronizar_fn=motor_sincronizar_fn
        )
        ubicacion, inmuebles, partidas_invalidas = await self._extraer_datos_inmuebles()
        datos["remate"].update(ubicacion)
        datos["inmuebles"] = inmuebles
        datos["partidas_revision_manual"] = partidas_invalidas

        # 3. Activación y Extracción de Cronograma
        await self.pre_validator.activar_pestana(
            indice=2,
            selector_panel=SELECTOR_PANEL_CRONOGRAMA,
            selector_contenido=SELECTOR_TABLA_CRONOGRAMA,
            motor_sincronizar_fn=motor_sincronizar_fn
        )
        datos["cronograma"] = await self._extraer_datos_cronograma()

        # 4. Retorno limpio al tab inicial ("Remates", índice 0) para dejar listo el DOM para la descarga del PDF
        await self.pre_validator.activar_pestana(
            indice=0,
            selector_panel=SELECTOR_PANEL_REMATE,
            motor_sincronizar_fn=motor_sincronizar_fn
        )

        return datos