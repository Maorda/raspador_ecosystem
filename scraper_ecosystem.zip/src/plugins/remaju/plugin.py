
from plugins.remaju.strategies import AuthenticateStrategy,SearchExpedienteStrategy
from plugins.registry import BasePlugin, register_plugin
from core.blackboard import ScrapingBlackboard
from infra.logger import get_logger
from typing import Optional
from playwright.async_api import async_playwright, Playwright, Browser, BrowserContext, Page

logger = get_logger("remaju_plugin")

@register_plugin("remaju")
class RemajuPlugin(BasePlugin):
    """Plugin de integración REMAJU utilizando BaseStrategy y Playwright."""

    def __init__(self, config: Optional[dict] = None) -> None:
        self.config = config or {}
        self.headless: bool = self.config.get("headless", False)
        self.auth_strategy = AuthenticateStrategy()
        self.search_strategy = SearchExpedienteStrategy()
        #self.extract_strategy = ExtractExpedienteStrategy()
        
        self._initialized: bool = False
        self._playwright: Optional[Playwright] = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._page: Optional[Page] = None

    async def initialize(self) -> None:
        """Inicializa Playwright, el navegador Chromium, contexto y pestaña."""
        try:
            logger.info("Iniciando recursos de Playwright para REMAJU...", extra={"headless": self.headless})
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(
                headless=self.headless,
                args=["--disable-dev-shm-usage", "--no-sandbox"]
            )
            self._context = await self._browser.new_context(
                viewport={"width": 1280, "height": 800},
                ignore_https_errors=True
            )
            self._page = await self._context.new_page()
            
            self._initialized = True
            logger.info("remaju_plugin_initialized", integration_ready=True)
        except Exception as e:
            logger.exception("Error crítico al inicializar RemajuPlugin.")
            await self.cleanup()
            raise RuntimeError(f"REMAJU_INIT_FAILED: {str(e)}")

    async def run(self, blackboard: ScrapingBlackboard) -> None:
        """Ejecuta las estrategias de autenticación y extracción usando la pestaña real."""
        if not self._initialized or not self._page:
            raise RuntimeError("RemajuPlugin debe inicializarse antes de run().")
        
        context_dict = getattr(blackboard, "context", {}) or {}
        params_dict = getattr(blackboard, "params", {}) or {}

        auth = await self.auth_strategy.execute(self._page, context_dict, **params_dict)
        if not auth.is_success:
            raise RuntimeError(f"{auth.error_category}: {auth.error}")

        search = await self.search_strategy.execute(self._page, context_dict, **params_dict)
        if not search.is_success:
            raise RuntimeError(f"{search.error_category}: {search.error}")

        #blackboard.data["remaju_results"] = extraction.value
        logger.info("Flujo completo de REMAJU ejecutado exitosamente.")

    async def cleanup(self) -> None:
        """Garantiza el cierre ordenado de página, contexto, navegador y playwright."""
        try:
            logger.info("Iniciando limpieza de recursos de RemajuPlugin...")
            
            if self._page:
                try:
                    await self._page.close()
                except Exception as ex:
                    logger.warning(f"Error cerrando página: {ex}")
                finally:
                    self._page = None

            if self._context:
                try:
                    await self._context.close()
                except Exception as ex:
                    logger.warning(f"Error cerrando contexto: {ex}")
                finally:
                    self._context = None

            if self._browser:
                try:
                    await self._browser.close()
                except Exception as ex:
                    logger.warning(f"Error cerrando navegador: {ex}")
                finally:
                    self._browser = None

            if self._playwright:
                try:
                    await self._playwright.stop()
                except Exception as ex:
                    logger.warning(f"Error deteniendo playwright: {ex}")
                finally:
                    self._playwright = None

        except Exception as e:
            logger.exception("Error inesperado durante la limpieza de RemajuPlugin.")
        finally:
            self._initialized = False
            logger.info("remaju_plugin_cleanup_completed")