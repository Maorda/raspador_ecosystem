"""Configuración de selectores y tiempos para el motor de interceptores en REMAJU."""
from __future__ import annotations

SELECTOR_MODAL_BIENVENIDA = "#dlgPopUp"
SELECTOR_BOTON_ACEPTAR = "#btnAceptarPopup"
SELECTOR_MASCARA_MODAL = "#dlgPopUp_modal"
SELECTOR_SPINNER_ESTADO = '#dlgEstado_content img[src*="loading-pj.gif"]'

DEFAULT_TIMEOUT_DETECCION_MODAL = 4_000
DEFAULT_TIMEOUT_CIERRE_MODAL = 10_000
DEFAULT_TIMEOUT_APARICION_SPINNER = 1_500
DEFAULT_TIMEOUT_DESAPARICION_SPINNER = 30_000