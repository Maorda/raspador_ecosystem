import os
from infra.logger import get_logger
from plugins.remaju.interceptors.factory import crear_motor_remaju
from interceptor_motor.interceptors.spinner import SpinnerTimeoutError
from interceptor_motor.contracts.base_modal import ModalCloseError
from typing import Any
from dotenv import load_dotenv
from core.result import Result
from strategies.base import BaseStrategy
from playwright.async_api import Page, TimeoutError as PlaywrightTimeoutError
import ddddocr
import base64
from infra.screenshot import take_debug_screenshot
load_dotenv(r"D:\libs\scraper_ecosystem\.env")

logger = get_logger("remaju_plugin")

class ExtractExpedienteStrategy(BaseStrategy):
    """Estrategia de extracción sincronizada asegurando la desaparición del spinner AJAX."""

    async def execute(self, tab: Any, context: dict[str, Any], **kwargs: Any) -> Result[dict[str, Any]]:
        try:
            page: Page = tab
            motor = crear_motor_remaju()
            logger.info("Sincronizando estado mediante motor interceptor antes de extraer...")
            
            await motor.execute_all(page)

            results_selector = "#tblResultadosExpediente"
            logger.info("Esperando tabla de resultados de expedientes...")
            await page.wait_for_selector(results_selector, state="visible", timeout=15000)

            extracted_data = {
                "expediente_id": kwargs.get("expediente_id") or context.get("expediente_id"),
                "status": "extracted"
            }

            logger.info("Extracción de expediente finalizada correctamente.")
            return Result.ok(extracted_data)

        except (ModalCloseError, SpinnerTimeoutError, PlaywrightTimeoutError) as err:
            logger.error(f"Error durante la extracción de expediente: {err}")
            await take_debug_screenshot(page, "extract_expediente_error")
            return Result.fail(str(err), "REMAJU_EXTRACTION_FAILED")
        except Exception as e:
            logger.exception("Error inesperado en ExtractExpedienteStrategy.")
            await take_debug_screenshot(page, "extract_expediente_critical_exception")
            return Result.fail(str(e), "REMAJU_EXTRACTION_FAILED")