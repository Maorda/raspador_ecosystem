from plugins.navigation import RemajuNavigator
from plugins.downloads import RemajuDownloader
import os
import json
import re
from pathlib import Path
import fitz  # PyMuPDF para verificar y leer texto del PDF descargado
from typing import Any, Dict, List
from playwright.async_api import Page, TimeoutError as PlaywrightTimeoutError

from core.result import Result
from strategies.base import BaseStrategy
from strategies.mixins import JSCapableMixin
from infra.database import DatabaseManager
from infra.logger import get_logger
from infra.screenshot import take_debug_screenshot
from plugins.remaju.interceptors.factory import crear_motor_remaju
from interceptor_motor import ModalCloseError, SpinnerTimeoutError
from pydantic import BaseModel, Field

# Importación de los nuevos módulos desacoplados de REMAJU
from plugins.remaju.pre_extract import PreExtractValidator
from plugins.extraccion import RemajuExtractor


logger = get_logger("remaju_plugin")


class RegisterExpedienteCommand(BaseModel):
    numero_expediente: str
    organo_jurisdiccional: str | None = None
    remate_info: dict[str, Any] = Field(default_factory=dict)
    inmueble_info: dict[str, Any] = Field(default_factory=dict)
    cronograma_info: dict[str, Any] = Field(default_factory=dict)
    pdf_path: str | None = None
    status: str = "COMPLETED"


class CommandDispatcher:
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager

    def execute_register_expediente(self, cmd: RegisterExpedienteCommand) -> Result[bool]:
        expediente = cmd.numero_expediente.strip()
        if not expediente:
            return Result.fail("numero_expediente no puede estar vacío.", "VALIDATION_ERROR")
        try:
            with self.db.get_connection() as conn:
                conn.execute(
                    """INSERT INTO expedientes
                    (numero_expediente, organo_jurisdiccional, remate_info,
                     inmueble_info, cronograma_info, pdf_path, status, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ON CONFLICT(numero_expediente) DO UPDATE SET
                        organo_jurisdiccional=excluded.organo_jurisdiccional,
                        remate_info=excluded.remate_info,
                        inmueble_info=excluded.inmueble_info,
                        cronograma_info=excluded.cronograma_info,
                        pdf_path=excluded.pdf_path,
                        status=excluded.status,
                        updated_at=CURRENT_TIMESTAMP
                    """,
                    (expediente, cmd.organo_jurisdiccional,
                     json.dumps(cmd.remate_info, ensure_ascii=False),
                     json.dumps(cmd.inmueble_info, ensure_ascii=False),
                     json.dumps(cmd.cronograma_info, ensure_ascii=False),
                     cmd.pdf_path, cmd.status),
                )
                return Result.ok(True)
        except Exception as exc:
            return Result.fail(str(exc), "COMMAND_ERROR")


class SearchExpedienteStrategy(BaseStrategy, JSCapableMixin):
    """Estrategia de búsqueda, paginación, extracción por pestañas, persistencia SQLite vía CommandDispatcher y revisión manual."""

    SELECTOR_CONTENEDOR_LISTADO = '[id="formBuscarRematesPublicados:listaRemate_content"]'
    SELECTOR_TARJETAS = '[id="formBuscarRematesPublicados:listaRemate_content"] .card.azul'
    SELECTOR_PAGINADOR = '[id="formBuscarRematesPublicados:listaRemate_paginator_bottom"]'
    SELECTOR_PAGINA_ACTIVA = SELECTOR_PAGINADOR + " .ui-paginator-page.ui-state-active"
    SELECTOR_BOTON_REGRESAR = "button:has-text('Regresar'), a:has-text('Regresar')"

    PATRON_PARTIDA_REGISTRAL = re.compile(r"P?\d{8}")

    MANUAL_REVIEW_DIR = "revision_manual"
    MANUAL_REVIEW_FILE = os.path.join(MANUAL_REVIEW_DIR, "errores_expedientes.json")
    
    PROCESADOS_DIR = "estado_procesamiento"
    PROCESADOS_FILE = os.path.join(PROCESADOS_DIR, "remates_procesados.json")
    
    PDF_DOWNLOAD_DIR = "downloads_pdf"
    MATERIA_EXCLUIDA = "obligacion de dar suma por alimentos"

    SCHEMA_MAP = {
        "mapeo_remate": {
            "expediente": "Expediente",
            "distritoJudicial": "Distrito Judicial",
            "instancia": "Instancia",
            "materia": "Materia",
            "resolucion": "Resolución",
            "fechaResolucion": "Fecha Resolución",
            "tipoCambio": "Tipo Cambio",
            "convocatoria": "Convocatoria",
            "tasacion": "Tasación",
            "precioBase": "Precio Base",
            "incrementoEntreOfertas": "Incremento entre ofertas",
            "arancel": "Arancel",
            "oblaje": "Oblaje",
            "descripcion": "Descripción",
            "numeroDeInscritos": "numero De Inscritos"
        },
        "mapeo_inmuebles": {
            "departamento": "Departamento",
            "provincia": "Provincia",
            "distrito": "Distrito",
            "partidaRegistral": "Partida Registral",
            "tipoInmueble": "Tipo Inmueble",
            "direccion": "Dirección",
            "cargaYGravamen": "Carga y/o Gravamen",
            "porcentajeRematar": "Porcentaje a Rematar"
        },
        "mapeo_cronograma": {
            "publicacionInicio": "Publicación e Inscripcion",
            "publicacionFin": "Publicación e Inscripcion",
            "validacionInscripcionInicio": "Validación de Inscripción",
            "validacionInscripcionFin": "Validación de Inscripción",
            "ofertasInicio": "Presentación de Ofertas",
            "ofertasFin": "Presentación de Ofertas",
            "pagoSaldoInicio": "Pago Saldo",
            "pagoSaldoFin": "Pago Saldo",
            "validacionSaldoInicio": "Validación del Saldo",
            "validacionSaldoFin": "Validación del Saldo"
        }
    }

    def __init__(self) -> None:
        self.db_manager = DatabaseManager()
        self.dispatcher = CommandDispatcher(self.db_manager)

    def sanitizar_texto(self, texto: Any) -> str:
        if texto is None:
            return ""
        return re.sub(r"\s+", " ", str(texto)).strip()

    async def execute(self, tab: Any, context: dict[str, Any], **kwargs: Any) -> Result[List[Dict[str, Any]]]:
        page: Page = tab
        motor = crear_motor_remaju()
        extracted_records = []

        try:
            logger.info("Sincronizando estado inicial tras el inicio de sesión...")
            await motor.execute_all(page)

            logger.info("Desplegando 'REMATES JUDICIALES' y haciendo clic en 'BUSCAR REMATES'...")
            await page.click("#linkRemateJudicial a", timeout=10000)
            await page.click("#menuForm\\:j_idt76", timeout=10000)
            await motor.execute_all(page)

            # Inicialización de componentes modulares
            pre_validator = PreExtractValidator(page)
            extractor = RemajuExtractor(page, self.SCHEMA_MAP, pre_validator)
            downloader = RemajuDownloader(page, descargas_path=self.PDF_DOWNLOAD_DIR)
            navigator = RemajuNavigator(page)

            has_next_page = True
            page_number = 1

            while has_next_page:
                logger.info(f"--- Procesando página de resultados #{page_number} ---")
                await navigator.esperar_listado(timeout=15000)

                count_cards = await page.locator(self.SELECTOR_TARJETAS).count()
                logger.info(f"Tarjetas detectadas en la página {page_number}: {count_cards}")

                for index in range(count_cards):
                    expediente_id = f"EXP-P{page_number}-C{index+1}"
                    try:
                        logger.info(f"Procesando tarjeta {index + 1} de {count_cards}...")

                        btn_detalle_selector = f'#formBuscarRematesPublicados\\:listaRemate\\:{index}\\:j_idt237'
                        await page.wait_for_selector(btn_detalle_selector, state="visible", timeout=5000)
                        await page.click(btn_detalle_selector)
                        await motor.execute_all(page)

                        await pre_validator.esperar_detalle_cargado(motor_sincronizar_fn=motor.execute_all)

                        # Momento 1 y Momento 2 integrados (incluye el retorno automático al tab 0 de Remates)
                        record_data = await extractor.extract_tab_remate_completo(motor_sincronizar_fn=motor.execute_all)
                        
                        remate_info = record_data.get("remate", {})
                        inmuebles_lista = record_data.get("inmuebles", [])
                        inmueble_info = inmuebles_lista[0] if inmuebles_lista else {}
                        
                        num_remate = remate_info.get("resolucion", "") or expediente_id
                        convocatoria = remate_info.get("convocatoria", "")
                        num_expediente = remate_info.get("expediente", expediente_id)

                        # Descarga y validación de PDF usando RemajuDownloader (DOM ya posicionado en Remates)
                        nombre_pdf = await downloader.download_resolucion_pdf(expediente_num=num_expediente)
                        record_data["pdf_path"] = nombre_pdf

                        if inmuebles_lista and not inmuebles_lista[0].get("porcentajeRematar") and nombre_pdf:
                            full_pdf_path = os.path.join(self.PDF_DOWNLOAD_DIR, nombre_pdf)
                            if os.path.exists(full_pdf_path):
                                inmuebles_lista[0]["porcentajeRematar"] = self._extraer_porcentaje_desde_pdf(full_pdf_path)

                        # Validación del formato de Partida Registral
                        partida = inmueble_info.get("partidaRegistral", "")
                        if partida and not self.PATRON_PARTIDA_REGISTRAL.match(partida):
                            logger.warning(f"Partida registral con formato atípico o inválido: '{partida}' en {num_expediente}")

                        if self._verificar_ya_procesado(num_remate, convocatoria):
                            logger.info(f"Remate '{num_remate}' ({convocatoria}) ya procesado. Saltando...")
                            await navigator.regresar_a_bandeja(motor_sincronizar_fn=motor.execute_all)
                            continue

                        materia = remate_info.get("materia", "").lower()
                        if self.MATERIA_EXCLUIDA in materia:
                            logger.info(f"Expediente excluido por materia: {materia}")
                        else:
                            # Registrar en SQLite mediante CommandDispatcher y Pydantic Command
                            cmd = RegisterExpedienteCommand(
                                numero_expediente=num_expediente,
                                organo_jurisdiccional=remate_info.get("distritoJudicial"),
                                remate_info=remate_info,
                                inmueble_info=inmueble_info,
                                cronograma_info=record_data.get("cronograma", {}),
                                pdf_path=record_data.get("pdf_path"),
                                status="COMPLETED"
                            )
                            cmd_result = self.dispatcher.execute_register_expediente(cmd)
                            if not cmd_result.is_success:
                                logger.error(f"Error al registrar expediente en BD: {cmd_result.error}")

                            extracted_records.append(record_data)
                            self._guardar_como_procesado(num_remate, convocatoria, record_data)
                            self._limpiar_revision_manual(num_expediente)

                        await navigator.regresar_a_bandeja(motor_sincronizar_fn=motor.execute_all)

                    except Exception as card_err:
                        logger.error(f"Error procesando tarjeta {index + 1} ({expediente_id}): {card_err}")
                        await take_debug_screenshot(page, f"error_tarjeta_p{page_number}_c{index+1}")
                        self._guardar_revision_manual(expediente_id, str(card_err))

                        try:
                            await navigator.regresar_a_bandeja(motor_sincronizar_fn=motor.execute_all)
                        except Exception:
                            pass

                # Avanzar a la siguiente página mediante RemajuNavigator
                avanzó = await navigator.avanzar_pagina(motor_sincronizar_fn=motor.execute_all)
                if avanzó:
                    page_number += 1
                else:
                    has_next_page = False
                    logger.info("Se completó el recorrido del paginador.")

            await self._ejecutar_flujo_revision_manual(page, motor)
            return Result.ok(extracted_records)

        except (ModalCloseError, SpinnerTimeoutError, PlaywrightTimeoutError) as err:
            logger.error(f"Error crítico en SearchExpedienteStrategy: {err}")
            await take_debug_screenshot(page, "search_strategy_error")
            return Result.fail(str(err), "REMAJU_SEARCH_FAILED")
        except Exception as e:
            logger.exception("Excepción inesperada en SearchExpedienteStrategy.")
            await take_debug_screenshot(page, "search_strategy_critical_exception")
            return Result.fail(str(e), "REMAJU_SEARCH_FAILED")

    def _extraer_porcentaje_desde_pdf(self, pdf_path: str) -> str:
        try:
            doc = fitz.open(pdf_path)
            texto = "".join([page.get_text() for page in doc])
            doc.close()
            match = re.search(r"(\d+(?:\.\d+)?)\s*%", texto)
            if match:
                return match.group(1)
        except Exception:
            pass
        return ""

    def _verificar_ya_procesado(self, numero_remate: str, convocatoria: str) -> bool:
        if not os.path.exists(self.PROCESADOS_FILE):
            return False
        try:
            with open(self.PROCESADOS_FILE, "r", encoding="utf-8") as f:
                procesados = json.load(f)
            clave = f"{numero_remate.strip()}_{convocatoria.strip()}"
            return clave in procesados
        except Exception:
            return False

    def _guardar_como_procesado(self, numero_remate: str, convocatoria: str, datos: Dict[str, Any]) -> None:
        os.makedirs(self.PROCESADOS_DIR, exist_ok=True)
        procesados = {}
        if os.path.exists(self.PROCESADOS_FILE):
            try:
                with open(self.PROCESADOS_FILE, "r", encoding="utf-8") as f:
                    procesados = json.load(f)
            except Exception:
                procesados = {}

        clave = f"{numero_remate.strip()}_{convocatoria.strip()}"
        procesados[clave] = {
            "numero_remate": numero_remate,
            "convocatoria": convocatoria,
            "expediente": datos.get("remate", {}).get("expediente", "")
        }

        with open(self.PROCESADOS_FILE, "w", encoding="utf-8") as f:
            json.dump(procesados, f, indent=4, ensure_ascii=False)

    async def _ejecutar_flujo_revision_manual(self, page: Page, motor: Any) -> None:
        if not os.path.exists(self.MANUAL_REVIEW_FILE):
            return

        try:
            with open(self.MANUAL_REVIEW_FILE, "r", encoding="utf-8") as f:
                errores = json.load(f)
        except Exception:
            errores = {}

        if not errores:
            return

        logger.info(f"Ejecutando segunda pasada (Revisión Manual) para {len(errores)} expedientes...")

        acordeon_exp = page.locator('#formBuscarRematesPublicados\\:j_idt149\\:j_idt152_header')
        if await acordeon_exp.is_visible(timeout=3000):
            await acordeon_exp.click()

        input_filtro = '#formBuscarRematesPublicados\\:j_idt149\\:filtroNroExpediente'
        pre_validator = PreExtractValidator(page)
        extractor = RemajuExtractor(page, self.SCHEMA_MAP, pre_validator)
        downloader = RemajuDownloader(page, descargas_path=self.PDF_DOWNLOAD_DIR)
        navigator = RemajuNavigator(page)

        for expediente, info in list(errores.items()):
            try:
                logger.info(f"Buscando expediente en revisión manual: {expediente}")
                await page.fill(input_filtro, "")
                await page.fill(input_filtro, expediente)

                await page.click("button:has-text('Aplicar'), button:has-text('Buscar')", timeout=5000)
                await motor.execute_all(page)

                cards_count = await page.locator(self.SELECTOR_TARJETAS).count()
                if cards_count > 0:
                    btn_detalle = page.locator('#formBuscarRematesPublicados\\:listaRemate\\:0\\:j_idt237').first
                    await btn_detalle.click()
                    await motor.execute_all(page)

                    record_data = await extractor.extract_tab_remate_completo(motor_sincronizar_fn=motor.execute_all)
                    
                    remate_info = record_data.get("remate", {})
                    inmuebles_lista = record_data.get("inmuebles", [])
                    inmueble_info = inmuebles_lista[0] if inmuebles_lista else {}

                    num_remate = remate_info.get("resolucion", "") or expediente
                    convocatoria = remate_info.get("convocatoria", "")
                    num_expediente = remate_info.get("expediente", expediente)

                    nombre_pdf = await downloader.download_resolucion_pdf(expediente_num=num_expediente)
                    record_data["pdf_path"] = nombre_pdf

                    cmd = RegisterExpedienteCommand(
                        numero_expediente=num_expediente,
                        organo_jurisdiccional=remate_info.get("distritoJudicial"),
                        remate_info=remate_info,
                        inmueble_info=inmueble_info,
                        cronograma_info=record_data.get("cronograma", {}),
                        pdf_path=record_data.get("pdf_path"),
                        status="COMPLETED"
                    )
                    self.dispatcher.execute_register_expediente(cmd)

                    self._guardar_como_procesado(num_remate, convocatoria, record_data)
                    self._limpiar_revision_manual(expediente)
                    await navigator.regresar_a_bandeja(motor_sincronizar_fn=motor.execute_all)
                    logger.info(f"¡Expediente {expediente} solucionado en segunda pasada y registrado en BD!")
                else:
                    logger.warning(f"El expediente {expediente} no arrojó resultados en la segunda pasada.")

            except Exception as ex:
                logger.error(f"Expediente {expediente} persistió con error: {ex}")
                self._guardar_revision_manual(expediente, str(ex))
                try:
                    await navigator.regresar_a_bandeja(motor_sincronizar_fn=motor.execute_all)
                except Exception:
                    pass

    def _guardar_revision_manual(self, expediente: str, error_msg: str) -> None:
        os.makedirs(self.MANUAL_REVIEW_DIR, exist_ok=True)
        data = {}
        if os.path.exists(self.MANUAL_REVIEW_FILE):
            try:
                with open(self.MANUAL_REVIEW_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                data = {}

        data[expediente] = {"estado": "error", "motivo": error_msg}
        with open(self.MANUAL_REVIEW_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        logger.warning(f"Expediente {expediente} guardado en revisión manual.")

    def _limpiar_revision_manual(self, expediente: str) -> None:
        if os.path.exists(self.MANUAL_REVIEW_FILE):
            try:
                with open(self.MANUAL_REVIEW_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if expediente in data:
                    del data[expediente]
                    with open(self.MANUAL_REVIEW_FILE, "w", encoding="utf-8") as f:
                        json.dump(data, f, indent=4, ensure_ascii=False)
                    logger.info(f"Expediente {expediente} eliminado de revisión manual.")
            except Exception as ex:
                logger.warning(f"Error limpiando revisión manual para {expediente}: {ex}")